<html>
<head>
<title>user registration</title>
</head>
<body>
<form action="regprocess.php" method="POST">

 USERNAME<br>
<input type="text" placeholder="username" name="username" maxlength="15"><br/>

 PASSWORD</br>
<input type="password" placeholder="password" name="password" maxlength="12"></br>

 NAME</br>
<input type="text" placeholder="name" name="name" maxlength="20"></br>

 ROOM</br>
<input type="text" placeholder="00A" name="room"></br>
 EMAIL<br>
<input type="email" placeholder="SOMEONE@HOTMAIL.COM" name="email"></br>

 PHONE</br>
<input type="tel" placeholder="9999999912" name="phone" maxlength="10"></br>
<input type="submit" value="REGISTER" style="cursor:pointer"></br>

</form>
</body>
</html>